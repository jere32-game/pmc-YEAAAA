const $ = (id) => document.getElementById(id);

let lang = 'en';
const t = (k, v) => tr(lang, k, v);

const send = async (msg) => {
  const r = await chrome.runtime.sendMessage(msg);
  if (!r || !r.ok) throw new Error((r && r.error) || t('errExt'));
  return r.data;
};

const say = (text, cls = '') => {
  $('msg').textContent = text;
  $('msg').className = cls;
};

function applyLang() {
  document.documentElement.lang = lang;
  document.title = t('popupTitle');
  for (const el of document.querySelectorAll('[data-i18n]')) el.textContent = t(el.dataset.i18n);
  for (const el of document.querySelectorAll('[data-i18n-ph]')) el.placeholder = t(el.dataset.i18nPh);
  $('lang').value = lang;
}

function show(state) {
  const mode = state.user ? 'done' : state.pending ? 'code' : 'start';
  for (const m of ['start', 'code', 'done']) $('s-' + m).hidden = m !== mode;
  if (mode === 'code') {
    $('who').textContent = state.pending.user;
    $('code').value = state.pending.code;
  }
  if (mode === 'done') $('me').textContent = state.user;
}

const refresh = async () => show(await send({ type: 'getState' }));

async function run(btn, fn) {
  btn.disabled = true;
  say('');
  try {
    await fn();
  } catch (e) {
    say(e.message, 'err');
  } finally {
    btn.disabled = false;
  }
}

$('gen').addEventListener('click', (e) =>
  run(e.target, async () => {
    await send({ type: 'setupStart', user: $('user').value });
    await refresh();
  })
);

$('user').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('gen').click();
});

$('copy').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText($('code').value);
    say(t('copied'), 'ok');
  } catch {
    $('code').select();
    say(t('selectCopy'));
  }
});

$('confirm').addEventListener('click', (e) =>
  run(e.target, async () => {
    await send({ type: 'setupConfirm' });
    await refresh();
    say(t('ready'), 'ok');
  })
);

for (const id of ['cancel', 'logout']) {
  $(id).addEventListener('click', (e) =>
    run(e.target, async () => {
      await send({ type: 'logout' });
      await refresh();
    })
  );
}

$('lang').addEventListener('change', async () => {
  lang = $('lang').value;
  await chrome.storage.local.set({ lang });
  applyLang();
  say('');
});

(async () => {
  lang = (await chrome.storage.local.get('lang')).lang || 'en';
  applyLang();
  await refresh();
})().catch((e) => say(e.message, 'err'));
