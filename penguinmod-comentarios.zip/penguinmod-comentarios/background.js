// PenguinMod Comentarios - service worker
// Los endpoints salen del código de tus dos extensiones de TurboWarp:
//   penguinapi.js -> GET  {API}users/profile?target=USUARIO
//                    GET  {API}projects/getproject?projectID=ID&requestType=metadata
//   database.js   -> GET  {DB}/storage/exists/KEY, GET {DB}/storage/get/KEY, POST {DB}/storage/set
importScripts('i18n.js');
const API = 'https://projects.penguinmod.com/api/v1/';
const DB = 'https://gen1x.derpygamer2142.com'; // servidor de Storage+. Si usas el tuyo, cambia solo esta línea.
const MAX_LEN = 500;
const MAX_ENTRIES = 500;
const KEY_RE = /pmc1\.([A-Za-z0-9_-]{43})/g;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const enc = new TextEncoder();
const toB64u = (bytes) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const fromB64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));
const ED = { name: 'Ed25519' };
// Idioma elegido en el popup (por defecto inglés). Se relee en cada mensaje.
let L = 'en';
const T = (k, v) => tr(L, k, v);
const getLang = async () => (await chrome.storage.local.get('lang')).lang || 'en';
const same = (a, b) => typeof a === 'string' && typeof b === 'string' && a.toLowerCase() === b.toLowerCase();

// ---------- API de PenguinMod ----------
let active = 0;
const waiting = [];
const limited = (fn) =>
  new Promise((resolve, reject) => {
    const run = () => {
      active++;
      fn().then(resolve, reject).finally(() => {
        active--;
        const next = waiting.shift();
        if (next) next();
      });
    };
    active < 6 ? run() : waiting.push(run);
  });

async function fetchProfile(user) {
  const res = await fetch(`${API}users/profile?target=${encodeURIComponent(user)}`, { cache: 'no-store' });
  if (!res.ok) throw new Error('profile');
  return res.json();
}

function collectStrings(o, out = []) {
  if (typeof o === 'string') out.push(o);
  else if (o && typeof o === 'object') for (const v of Object.values(o)) collectStrings(v, out);
  return out;
}

// No sé cómo se llama el campo de la descripción en la API, así que reviso todos los textos del perfil.
function keysInProfile(profile) {
  const found = new Set();
  for (const s of collectStrings(profile)) for (const m of s.matchAll(KEY_RE)) found.add(m[1]);
  return [...found];
}

// Creador del proyecto, desde los metadatos del proyecto.
const authorCache = new Map();
function authorFrom(m) {
  if (!m || typeof m !== 'object') return null;
  const a = m.author;
  const options = [a && typeof a === 'object' ? a.username : a, m.authorUsername, m.owner && typeof m.owner === 'object' ? m.owner.username : m.owner, m.username];
  const name = options.find((x) => typeof x === 'string' && x.trim());
  return name ? name.trim() : null;
}
async function getAuthor(pid) {
  const hit = authorCache.get(pid);
  if (hit && Date.now() - hit.at < 600000) return hit.name;
  let name = null;
  try {
    const res = await fetch(`${API}projects/getproject?projectID=${encodeURIComponent(pid)}&requestType=metadata`, { cache: 'no-store' });
    if (res.ok) name = authorFrom(await res.json());
  } catch {}
  if (name) authorCache.set(pid, { name, at: Date.now() });
  return name;
}

// ---------- Base de datos (Storage+) ----------
async function okJson(res) {
  if (!res.ok) throw new Error('db');
  return res.json();
}

async function dbGet(key) {
  const k = encodeURIComponent(key);
  const ex = await okJson(await fetch(`${DB}/storage/exists/${k}`, { cache: 'no-store' }));
  if (!ex.exists) return null;
  const data = await okJson(await fetch(`${DB}/storage/get/${k}`, { cache: 'no-store' }));
  return data.value ?? null;
}

async function dbSet(key, value) {
  const res = await fetch(`${DB}/storage/set`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key, value, lock: false }),
  });
  const data = await okJson(res);
  if (data && data.error) throw new Error(String(data.error));
}

// Una sola lista por proyecto. Entradas:
//   comentario: { k:'c', id, u, t, ts, p?, sig }   (p = id del comentario principal al que responde)
//   acción:     { k:'a', id, u, ts, a:'del'|'pin'|'unpin', x:<id del comentario>, sig }
const keyFor = (pid) => `pmc_v2_${pid}`;
const str = (v) => typeof v === 'string';
const asList = (v) =>
  Array.isArray(v)
    ? v.filter(
        (e) =>
          e && str(e.id) && str(e.u) && str(e.sig) && typeof e.ts === 'number' &&
          (e.k === 'a' ? ['del', 'pin', 'unpin'].includes(e.a) && str(e.x) : str(e.t) && (e.p == null || str(e.p)))
      )
    : [];

// Leer, cambiar, escribir y comprobar. Si dos personas escriben a la vez, reintenta.
// Si la lectura falla lanza error, así nunca se pisa la lista con una vacía.
async function mutate(key, change, done) {
  for (let i = 0; i < 4; i++) {
    const next = change(asList(await dbGet(key)));
    await dbSet(key, next);
    await sleep(300 + Math.random() * 500);
    if (done(asList(await dbGet(key)))) return true;
  }
  return false;
}

// ---------- Firmas ----------
const payload = (pid, e) =>
  enc.encode(JSON.stringify(e.k === 'a' ? ['pmc2', 'a', pid, e.u, e.ts, e.id, e.a, e.x] : ['pmc2', 'c', pid, e.u, e.ts, e.id, e.p || '', e.t]));

async function sign(session, pid, e) {
  const key = await crypto.subtle.importKey('jwk', session.priv, ED, false, ['sign']);
  e.sig = toB64u(new Uint8Array(await crypto.subtle.sign(ED, key, payload(pid, e))));
  return e;
}

async function verifyWith(pubB64, sig, data) {
  try {
    const key = await crypto.subtle.importKey('raw', fromB64u(pubB64), ED, false, ['verify']);
    return await crypto.subtle.verify(ED, key, sig, data);
  } catch {
    return false;
  }
}

async function verifyEntry(pid, e, seen, profiles) {
  let sig;
  try {
    sig = fromB64u(e.sig);
  } catch {
    return false;
  }
  const data = payload(pid, e);
  if (seen[e.u] && (await verifyWith(seen[e.u], sig, data))) return true;
  if (!profiles.has(e.u)) profiles.set(e.u, limited(() => fetchProfile(e.u)).then(keysInProfile).catch(() => []));
  for (const pub of await profiles.get(e.u)) {
    if (await verifyWith(pub, sig, data)) {
      seen[e.u] = pub; // esta clave estaba en la descripción real de ese usuario
      return true;
    }
  }
  return false;
}

// ---------- Verificación de perfil ----------
async function setupStart(user) {
  user = String(user || '').trim();
  if (!user || user.length > 40 || /[\s/\\?#&]/.test(user)) throw new Error(T('errUser'));
  let pair;
  try {
    pair = await crypto.subtle.generateKey(ED, true, ['sign', 'verify']);
  } catch {
    throw new Error(T('errChrome'));
  }
  const priv = await crypto.subtle.exportKey('jwk', pair.privateKey);
  const pub = toB64u(new Uint8Array(await crypto.subtle.exportKey('raw', pair.publicKey)));
  await chrome.storage.local.set({ pending: { user, priv, pub } });
  return { user, code: 'pmc1.' + pub };
}

async function setupConfirm() {
  const { pending } = await chrome.storage.local.get('pending');
  if (!pending) throw new Error(T('errGenFirst'));
  let profile;
  try {
    profile = await fetchProfile(pending.user);
  } catch {
    throw new Error(T('errProfile'));
  }
  if (!keysInProfile(profile).includes(pending.pub)) throw new Error(T('errNoCode'));
  const { seen = {} } = await chrome.storage.local.get('seen');
  seen[pending.user] = pending.pub;
  await chrome.storage.local.set({ session: pending, seen });
  await chrome.storage.local.remove('pending');
  return { user: pending.user };
}

async function getState() {
  const { session, pending } = await chrome.storage.local.get(['session', 'pending']);
  return {
    user: session ? session.user : null,
    pending: pending ? { user: pending.user, code: 'pmc1.' + pending.pub } : null,
  };
}

// ---------- Comentarios ----------
async function getComments(pid) {
  const list = asList(await dbGet(keyFor(pid)));
  const [{ seen = {}, session }, author] = await Promise.all([chrome.storage.local.get(['seen', 'session']), getAuthor(pid)]);
  const profiles = new Map();
  const ok = await Promise.all(list.map((e) => verifyEntry(pid, e, seen, profiles)));
  await chrome.storage.local.set({ seen });

  const comments = new Map();
  const actions = [];
  list.forEach((e, i) => {
    if (e.k === 'a') {
      if (ok[i]) actions.push(e);
    } else comments.set(e.id, { ...e, ok: ok[i] });
  });

  // Solo cuentan las acciones con firma válida: borrar (su autor o el creador) y fijar (solo el creador).
  const deleted = new Set();
  let pinned = null;
  for (const e of actions.sort((a, b) => a.ts - b.ts)) {
    const asAuthor = same(e.u, author);
    if (e.a === 'del') {
      const target = comments.get(e.x);
      if (asAuthor || (target && same(target.u, e.u))) deleted.add(e.x);
    } else if (asAuthor) {
      if (e.a === 'pin') pinned = e.x;
      else if (pinned === e.x) pinned = null;
    }
  }

  const visible = [...comments.values()].filter((c) => !deleted.has(c.id));
  const tops = visible.filter((c) => !c.p);
  const topIds = new Set(tops.map((c) => c.id));
  const replies = new Map();
  for (const c of visible) {
    if (c.p && topIds.has(c.p)) {
      if (!replies.has(c.p)) replies.set(c.p, []);
      replies.get(c.p).push(c);
    }
  }
  const me = session ? session.user : null;
  const view = (c) => ({
    id: c.id, u: c.u, t: c.t.slice(0, MAX_LEN), ts: c.ts, ok: c.ok,
    creator: c.ok && same(c.u, author),
    canDelete: !!me && (same(c.u, me) || same(me, author)),
  });
  const out = tops.map((c) => ({
    ...view(c),
    pinned: c.id === pinned,
    replies: (replies.get(c.id) || []).sort((a, b) => a.ts - b.ts).map(view),
  }));
  out.sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.ts - a.ts);
  const count = out.reduce((n, c) => n + 1 + c.replies.length, 0);
  return { me, author, isAuthor: !!me && same(me, author), count, comments: out };
}

async function post(pid, text, parent) {
  const { session } = await chrome.storage.local.get('session');
  if (!session) throw new Error(T('errVerify'));
  text = String(text || '').trim();
  if (!text) throw new Error(T('errEmpty'));
  if (text.length > MAX_LEN) throw new Error(T('errMax', { n: MAX_LEN }));
  const c = { k: 'c', id: crypto.randomUUID(), u: session.user, t: text, ts: Date.now() };
  if (parent) {
    const p = asList(await dbGet(keyFor(pid))).find((e) => e.k !== 'a' && e.id === String(parent));
    if (!p) throw new Error(T('errParent'));
    c.p = p.p || p.id; // las respuestas siempre cuelgan del comentario principal
  }
  await sign(session, pid, c);
  const done = await mutate(keyFor(pid), (l) => [...l, c].slice(-MAX_ENTRIES), (l) => l.some((x) => x.id === c.id));
  if (!done) throw new Error(T('errSave'));
}

async function act(pid, a, x) {
  const { session } = await chrome.storage.local.get('session');
  if (!session) throw new Error(T('errVerify'));
  if (!['del', 'pin', 'unpin'].includes(a)) throw new Error(T('errAction'));
  const author = await getAuthor(pid);
  const isAuthor = same(session.user, author);
  const target = asList(await dbGet(keyFor(pid))).find((e) => e.k !== 'a' && e.id === x);
  if (a === 'del') {
    if (!target) return;
    if (!isAuthor && !same(target.u, session.user)) throw new Error(T('errDelete'));
  } else {
    if (!isAuthor) throw new Error(T('errPinCreator'));
    if (a === 'pin' && (!target || target.p)) throw new Error(T('errPinTop'));
  }
  const e = await sign(session, pid, { k: 'a', id: crypto.randomUUID(), u: session.user, ts: Date.now(), a, x });
  // Al borrar se quita el texto de la base de datos y se deja la marca firmada, para que nadie lo reponga.
  const change = (l) => [...(a === 'del' ? l.filter((c) => c.k === 'a' || (c.id !== x && c.p !== x)) : l), e].slice(-MAX_ENTRIES);
  const done = await mutate(keyFor(pid), change, (l) => l.some((c) => c.id === e.id));
  if (!done) throw new Error(T('errActFail'));
}

// ---------- Mensajes ----------
const checkPid = (p) => {
  p = String(p || '');
  if (!/^[A-Za-z0-9_-]{4,40}$/.test(p)) throw new Error(T('errProject'));
  return p;
};

const handlers = {
  getState: () => getState(),
  setupStart: (m) => setupStart(m.user),
  setupConfirm: () => setupConfirm(),
  logout: () => chrome.storage.local.remove(['session', 'pending']),
  getComments: (m) => getComments(checkPid(m.projectId)),
  post: (m) => post(checkPid(m.projectId), m.text, m.parent),
  act: (m) => act(checkPid(m.projectId), String(m.a), String(m.x)),
};

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  const h = msg && handlers[msg.type];
  if (!h) return false;
  Promise.resolve()
    .then(async () => {
      L = await getLang();
      return h(msg);
    })
    .then(
      (data) => send({ ok: true, data }),
      (e) => send({ ok: false, error: (e && e.message) || String(e) })
    );
  return true;
});
