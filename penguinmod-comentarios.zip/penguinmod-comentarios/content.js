(() => {
  'use strict';

  // 'before' = justo encima de "Updated ..." (donde marcaste la línea roja). 'after' = justo debajo del bloque de fechas.
  const PLACEMENT = 'before';
  const PFP = 'https://projects.penguinmod.com/api/v1/users/getpfp?username=';
  const PROFILE = 'https://penguinmod.com/profile?user=';

  // Idioma elegido en el popup (por defecto inglés).
  let lang = 'en';
  const t = (k, v) => tr(lang, k, v);

  const send = async (msg) => {
    const r = await chrome.runtime.sendMessage(msg);
    if (!r || !r.ok) throw new Error((r && r.error) || t('errExt'));
    return r.data;
  };

  const CSS = `
:host{display:block;margin:16px 0}
.box{background:#111a2b;border:1px solid #243247;border-radius:10px;padding:14px;color:#e8edf5;font-size:14px;line-height:1.45;box-sizing:border-box}
.head{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:10px}
.title{margin:0;font-size:16px}
.muted{color:#8b97aa;font-size:12px}
p.muted{margin:6px 0}
.err{color:#ff7b7b;font-size:12px}
p.err{margin:6px 0}
textarea{width:100%;box-sizing:border-box;min-height:64px;padding:8px;border-radius:8px;border:1px solid #243247;background:#0c1422;color:inherit;font:inherit;resize:vertical}
textarea:focus,button:focus-visible,a:focus-visible{outline:2px solid #2f7df6;outline-offset:1px}
.row{display:flex;align-items:center;gap:10px;margin-top:6px}
.row .err{flex:1}
.btn{margin-left:auto;background:#2f7df6;color:#fff;border:0;border-radius:8px;padding:7px 16px;font:inherit;cursor:pointer}
.btn:disabled{opacity:.5;cursor:default}
.link{background:none;border:0;padding:0;color:#7db4ff;font:inherit;font-size:12px;cursor:pointer;text-decoration:underline}
.link:disabled{opacity:.5;cursor:default}
.who{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.who .av{width:24px;height:24px}
.list{margin-top:12px}
.c{display:flex;gap:10px;padding:12px 0;border-top:1px solid #1f2b3f}
.c.pinned{background:#15213a;border-radius:8px;border-top-color:transparent;padding:12px;margin:4px 0}
.c.reply{border-top:0;padding:10px 0 0}
.av{flex:none;width:36px;height:36px;border-radius:50%;background:#243247;object-fit:cover;display:block}
.reply .av{width:28px;height:28px}
.av.ph{display:flex;align-items:center;justify-content:center;font-weight:600;font-size:13px;color:#cfe0ff;background:#2a3b57}
.avl{flex:none;display:block;height:max-content;border-radius:50%}
.body{flex:1;min-width:0}
.meta{display:flex;flex-wrap:wrap;align-items:center;gap:8px}
a.name{color:#e8edf5;font-weight:600;text-decoration:none}
a.name:hover{text-decoration:underline}
.ok{color:#4ade80;font-size:12px}
.tag{font-size:11px;padding:1px 7px;border-radius:999px;border:1px solid #3a4c6b;color:#b4c3dd}
.tag.pin{border-color:#8a7430;color:#f5c542}
.dim .text{color:#aab4c4}
.text{margin:4px 0 0;white-space:pre-wrap;overflow-wrap:anywhere}
.acts{display:flex;flex-wrap:wrap;gap:14px;margin-top:6px}
.acts:empty{display:none}
.replies{margin-top:2px}
.slot{margin-top:8px}
.slot:empty{display:none}
`;

  function h(tag, props = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v);
    }
    el.append(...kids.flat().filter((x) => x != null && x !== false));
    return el;
  }

  // ---- Qué proyecto es ----
  const ID_RE = /^[A-Za-z0-9_-]{4,40}$/;
  function projectId() {
    let hash = '';
    try {
      hash = decodeURIComponent(location.hash.replace(/^#\/?/, '')).split(/[?&/]/)[0];
    } catch {}
    const q = new URLSearchParams(location.search);
    const fromQuery = ['id', 'project', 'projectId', 'projectID', 'pid'].map((k) => q.get(k)).find((v) => v && ID_RE.test(v));
    const seg = location.pathname.split('/').filter(Boolean).pop() || '';
    const withDigit = (v) => (v && ID_RE.test(v) && /\d/.test(v) ? v : null);
    return fromQuery || withDigit(hash) || withDigit(seg) || null;
  }

  // Busca el bloque de fechas ("Updated ..." / "Originally Uploaded ...") y devuelve su contenedor.
  function findAnchor() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n; (n = walker.nextNode()); ) {
      if (!/^\s*(Updated|Actualizado)\b/.test(n.nodeValue)) continue;
      let el = n.parentElement;
      while (el && el !== document.body && !/Originally|originalmente/i.test(el.textContent)) el = el.parentElement;
      if (el && el !== document.body) return el;
    }
    return null;
  }

  // ---- Piezas de interfaz ----
  const profileUrl = (u) => PROFILE + encodeURIComponent(u);

  function avatar(u) {
    const img = h('img', { class: 'av', alt: '', src: PFP + encodeURIComponent(u), loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer' });
    img.addEventListener('error', () => img.replaceWith(h('span', { class: 'av ph' }, ([...u][0] || '?').toUpperCase())));
    return h('a', { class: 'avl', href: profileUrl(u), target: '_blank', rel: 'noopener noreferrer', title: t('viewProfile', { u }) }, img);
  }

  const nameLink = (u) => h('a', { class: 'name', href: profileUrl(u), target: '_blank', rel: 'noopener noreferrer', title: t('viewProfile', { u }) }, u);

  function makeComposer({ placeholder, button, initial = '', onSubmit, onCancel }) {
    const ta = h('textarea', { maxlength: '500', rows: '3', placeholder });
    ta.value = initial;
    const count = h('span', { class: 'muted' }, `${ta.value.length}/500`);
    const err = h('span', { class: 'err' });
    const btn = h('button', { class: 'btn', type: 'button' }, button);
    const cancel = onCancel ? h('button', { class: 'link', type: 'button', onclick: onCancel }, t('cancel')) : null;
    const submit = async () => {
      if (btn.disabled) return;
      btn.disabled = true;
      err.textContent = '';
      try {
        await onSubmit(ta.value);
        ta.value = '';
        count.textContent = '0/500';
      } catch (e) {
        err.textContent = e.message;
      } finally {
        btn.disabled = false;
      }
    };
    btn.addEventListener('click', submit);
    ta.addEventListener('input', () => (count.textContent = `${ta.value.length}/500`));
    for (const ev of ['keydown', 'keyup', 'keypress']) ta.addEventListener(ev, (e) => e.stopPropagation());
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submit();
    });
    return {
      el: h('div', {}, ta, h('div', { class: 'row' }, count, err, cancel, btn)),
      focus: () => {
        ta.focus();
        ta.setSelectionRange(ta.value.length, ta.value.length);
      },
    };
  }

  function createPanel(pid) {
    const host = h('div', { id: 'pmc-root' });
    host._pid = pid;
    const root = host.attachShadow({ mode: 'open' });
    const title = h('h3', { class: 'title' }, t('comments'));
    const refresh = h('button', { class: 'link', type: 'button', onclick: () => load() }, t('refresh'));
    const composer = h('div');
    const status = h('p', { class: 'err' });
    const list = h('div', { class: 'list' });
    root.append(h('style', {}, CSS), h('section', { class: 'box' }, h('div', { class: 'head' }, title, refresh), composer, status, list));

    let replySlot = null;
    let composerFor;
    let flashTimer;

    const flash = (m) => {
      status.textContent = m;
      clearTimeout(flashTimer);
      flashTimer = setTimeout(() => (status.textContent = ''), 6000);
    };
    const closeReply = () => {
      if (replySlot) replySlot.replaceChildren();
      replySlot = null;
    };

    async function doAct(a, id) {
      try {
        await send({ type: 'act', projectId: pid, a, x: id });
        await load();
      } catch (e) {
        flash(e.message);
      }
    }

    function openReply(c, rootId, slot) {
      closeReply();
      replySlot = slot;
      const comp = makeComposer({
        placeholder: t('replyTo', { u: c.u }),
        button: t('reply'),
        initial: c.id !== rootId ? `@${c.u} ` : '',
        onCancel: closeReply,
        onSubmit: async (text) => {
          await send({ type: 'post', projectId: pid, text, parent: rootId });
          closeReply();
          await load();
        },
      });
      slot.replaceChildren(comp.el);
      comp.focus();
    }

    function commentNode(c, data, rootId, isReply) {
      const slot = h('div', { class: 'slot' });
      const acts = h('div', { class: 'acts' });
      const act = (label, fn) => acts.append(h('button', { class: 'link', type: 'button', onclick: fn }, label));
      if (data.me) act(t('reply'), () => openReply(c, rootId, slot));
      if (!isReply && data.isAuthor) act(c.pinned ? t('unpin') : t('pin'), () => doAct(c.pinned ? 'unpin' : 'pin', c.id));
      if (c.canDelete) act(t('delete'), () => confirm(t('confirmDelete')) && doAct('del', c.id));
      return h(
        'article',
        { class: 'c' + (c.ok ? '' : ' dim') + (c.pinned ? ' pinned' : '') + (isReply ? ' reply' : '') },
        avatar(c.u),
        h(
          'div',
          { class: 'body' },
          h(
            'div',
            { class: 'meta' },
            nameLink(c.u),
            c.creator ? h('span', { class: 'tag' }, t('creator')) : null,
            c.pinned ? h('span', { class: 'tag pin' }, t('pinned')) : null,
            c.ok
              ? h('span', { class: 'ok', title: t('verifiedTip') }, t('verified'))
              : h('span', { class: 'muted', title: t('unverifiedTip') }, t('unverified')),
            h('time', { class: 'muted' }, new Date(c.ts).toLocaleString(lang))
          ),
          h('p', { class: 'text' }, c.t),
          acts,
          slot,
          c.replies && c.replies.length ? h('div', { class: 'replies' }, c.replies.map((r) => commentNode(r, data, rootId, true))) : null
        )
      );
    }

    function renderComposer(me) {
      if (!me) {
        composer.replaceChildren(h('p', { class: 'muted' }, t('loginHint')));
        return;
      }
      const comp = makeComposer({
        placeholder: t('writePh'),
        button: t('post'),
        onSubmit: async (text) => {
          await send({ type: 'post', projectId: pid, text });
          await load();
        },
      });
      composer.replaceChildren(h('div', { class: 'who' }, avatar(me), h('span', { class: 'muted' }, t('commentingAs'), h('strong', {}, me), ' \u2713')), comp.el);
    }

    function renderList(data) {
      title.textContent = t('commentsN', { n: data.count });
      closeReply();
      if (!data.comments.length) {
        list.replaceChildren(h('p', { class: 'muted' }, t('empty')));
        return;
      }
      list.replaceChildren(...data.comments.map((c) => commentNode(c, data, c.id, false)));
    }

    async function load() {
      refresh.disabled = true;
      try {
        const data = await send({ type: 'getComments', projectId: pid });
        if (composerFor !== data.me) {
          composerFor = data.me;
          renderComposer(data.me);
        }
        renderList(data);
      } catch (e) {
        list.replaceChildren(h('p', { class: 'err' }, t('errLoad', { e: e.message })));
      } finally {
        refresh.disabled = false;
      }
    }

    load();
    const timer = setInterval(() => {
      if (!host.isConnected) clearInterval(timer);
      else if (!document.hidden && !replySlot) load();
    }, 60000);
    return host;
  }

  // La página es una SPA: reviso cada segundo si hay que (re)montar el panel.
  let host = null;
  let lastHref = '';
  let tries = 0;

  const unmount = () => {
    if (host) host.remove();
    host = null;
  };

  function tick() {
    if (location.href !== lastHref) {
      lastHref = location.href;
      tries = 0;
    }
    const pid = projectId();
    if (!pid) return unmount();
    if (host && host.isConnected && host._pid === pid) return;
    if (host && host._pid !== pid) unmount();
    if (tries++ > 120) return;
    const anchor = findAnchor();
    if (!anchor) return;
    host = createPanel(pid);
    if (PLACEMENT === 'after') anchor.after(host);
    else anchor.before(host);
  }

  const start = async () => {
    lang = (await chrome.storage.local.get('lang')).lang || 'en';
    setInterval(tick, 1000);
    tick();
  };
  start();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.lang) return;
    lang = changes.lang.newValue || 'en';
    unmount();
    tick();
  });
})();
